a=int(input("Enter the first number = "))
b=int(input("enter the second number = "))
opr = input("enter the operator ,+ , - , * , / , //  " "= ")
if opr =="+":
    print(a+b)
elif opr == " -":
    print(a-b)
elif opr =="*":
    print(a*b)
elif opr =="/":
    print(a/b)
elif opr =="//":
    print(a//b)
else :
    print("invalid")
    